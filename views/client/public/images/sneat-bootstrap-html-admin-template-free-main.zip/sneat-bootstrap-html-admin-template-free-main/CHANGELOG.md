# Changelog

All notable changes to this template will be documented in this file.

## [1.1.1] - [2023-09-27]

### Fixed

- Minor Improvements

## [1.1.0] - [2023-09-13]

### Fixed

- Minor bug fixes and UI improvements

### Updated

- Updated Third party libraries
- Updated Font weights for better appearance

### Added

- Added highlight border on hover for inputs

## [1.0.1] - [2022-04-29]

### Fixed

- Minor CSS fixes and improvements

## [1.0.0] - [2022-02-11]

### Added

- Initial Release
